# Sistema IMP

Aplicação React/Vite com API Express e PostgreSQL (Drizzle ORM), preparada para teste no Vercel.

## Deploy de teste

1. Crie um repositório GitHub e envie os ficheiros deste projeto. Não envie `.env` nem credenciais.
2. Importe o repositório no Vercel. O projeto usa `npm run build` e publica a pasta `dist`.
3. Crie uma base PostgreSQL gerida (por exemplo, Neon ou Supabase) e adicione `DATABASE_URL` nas Environment Variables do Vercel para os ambientes de teste pretendidos. Use a URL com SSL fornecida pelo provedor.
4. Antes de usar a aplicação, aplique o esquema à base: localmente, com `DATABASE_URL` disponível, execute `npm install` e `npm run db:push`. Confirme a operação no banco de teste correto.
5. Faça um novo deploy no Vercel. `/api/health` verifica a API; `/api/faturas` exercita uma consulta ao banco.

O Vercel não cria a instância PostgreSQL. O código define o esquema Drizzle; `db:push` cria/atualiza as tabelas no PostgreSQL escolhido. O seed não é executado automaticamente em cada inicialização serverless; se os dados de demonstração forem necessários, use o endpoint `POST /api/db/seed` uma vez, somente no banco de teste.

## Desenvolvimento local

```sh
npm install
npm run dev
```

Configure `DATABASE_URL` num `.env` local ignorado pelo Git. Para iniciar sem banco, a interface ainda usa os dados de demonstração locais, mas as operações da API PostgreSQL não estarão disponíveis.

## Sessão móvel

A sessão e o módulo atual são guardados no `localStorage` do navegador e persistem ao atualizar a página. Sair da conta remove esses dados. Limpar os dados do navegador ou abrir uma sessão privada termina a persistência local.
