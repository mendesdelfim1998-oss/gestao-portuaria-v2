import app from '../server.ts';

// Vercel rewrites nested API URLs to this function and forwards the path as `path`.
export default function handler(req: any, res: any) {
  const route = req.query?.path;
  if (typeof route === 'string' && route.length > 0) {
    req.url = `/api/${route}${req.url?.includes('?') ? `?${req.url.split('?').slice(1).join('?')}` : ''}`;
  }
  return app(req, res);
}
