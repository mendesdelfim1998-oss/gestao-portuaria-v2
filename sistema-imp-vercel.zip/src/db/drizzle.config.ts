// src/db/drizzle.config.ts
import { defineConfig } from "drizzle-kit";
import * as dotenv from "dotenv";

// Load environment variables from .env file.
dotenv.config();

const connectionString = process.env.DATABASE_URL;
const sqlHost = process.env.SQL_HOST;
const sqlDbName = process.env.SQL_DB_NAME;
const user = process.env.SQL_ADMIN_USER || process.env.SQL_USER;
const password = process.env.SQL_ADMIN_PASSWORD || process.env.SQL_PASSWORD;

if (!connectionString && (!sqlHost || !sqlDbName || !user || !password)) {
  throw new Error("Set DATABASE_URL or SQL_HOST, SQL_DB_NAME, SQL_USER and SQL_PASSWORD.");
}

export default defineConfig({
  schema: "./src/db/schema.ts",
  out: "./drizzle", // Output directory for migrations.
  dialect: "postgresql",
  schemaFilter: ["public"],
  dbCredentials: {
    ...(connectionString ? { url: connectionString } : {
      host: sqlHost!,
      user: user!,
      password: password!,
      database: sqlDbName!,
      ssl: process.env.SQL_SSL === 'true',
    }),
  },
  verbose: true, // Enable verbose output.
});
